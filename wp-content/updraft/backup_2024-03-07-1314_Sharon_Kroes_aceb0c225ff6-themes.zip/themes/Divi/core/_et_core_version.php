<?php

// Note, this will be updated automatically during grunt release task3.0.64
$ET_CORE_VERSION = '3.0.64';
