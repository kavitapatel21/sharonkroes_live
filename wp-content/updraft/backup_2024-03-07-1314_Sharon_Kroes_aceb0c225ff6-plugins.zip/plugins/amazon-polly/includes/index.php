<?php
/**
 * Silence is golden
 *
 * @link       amazon.com
 * @since      1.0.0
 *
 * @package    Amazonpolly/include
 */

// None.
